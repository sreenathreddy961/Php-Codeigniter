<?php
	$this->load->view('include/top');
	//$this->load->view('include/template');
	//$this->load->view('include/right');
	$this->load->view($content);
	$this->load->view('include/footer');
?>