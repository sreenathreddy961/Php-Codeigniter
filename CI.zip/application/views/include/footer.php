<html>
<head>
	<style>
		.footer
		{
	  		left: 0;
	  		top:90%;
	  		position: fixed;
	  		width:100%;
	  		background-color: #efe6d3;
	  		height: 11%;
		}
		h6
		{
			text-align: center;
			margin-left: 30%;
	    	width:40%;
	    	color:black;
		}
		h6 span
		{
			color: red;
		}
	</style>
</head>
<body >
	<div class="split footer" id="footer">
		<h6>All Copy Rights Reserved @ <span> 2021</span></h6>
	</div>
</body>
</html>