<html>
<head>
<style>
	.left 
	{
  		left: 0;
  		width:7%;
  		height:1200px;
  		margin-top:7%;
  		position: absolute;
  		background-color: #123;
	}
	.left a 
	{
		color:white;
    text-decoration:none;
	}
</style>
</head>
<body>
<div class="split left" id="left">

  <br><a href="https://www.google.com/intl/en-GB/gmail/about/#" >Gmail</a><br>
  
  <br><a href="https://www.linkedin.com/login" >LinkedIn</a><br>
  
  <br><a href="https://www.w3schools.com/" >W3 Sch.</a><br>
</div>
</html>