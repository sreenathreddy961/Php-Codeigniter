<!DOCTYPE html>
<html>
<head>
  <title>Codeigniter Form Validation</title>
 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
<div class="container">
 <h1> Thank You for Registered</h1>
</div>
</body>
</html>