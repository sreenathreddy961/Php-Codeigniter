$(document).ready(function(){
	$("#display").load("db.php");
}
);