<html>
<head>
	<style>
	.top 
	{
  		left: 0;
  		top:0;
  		position: absolute;
  		width:100%;
  		background-color: #112;
	}
	.top img 
	{
  		width: 190px;
  		border-radius: 60%;
	}
	.top h2 
	{
		float:right;
    	width:40%;
    	color:white;
	}
	#image2 
	{
		float:right;
	}
</style>
</head>
<body >
<div class="split top" id="top">
<img src="https://stackify.com/wp-content/uploads/2018/09/Java-Debugging-Tips-1280x720.jpg">
<img id="image2" src="https://cdn.app.compendium.com/uploads/user/e7c690e8-6ff9-102a-ac6d-e4aebca50425/ed5569e8-c0dd-458c-8450-cde6300093bd/File/ea0956c357674c485ab6191c662ede95/java_25_yrs_rgb.png">
<h2>SignUp Form</h2>
</div>
</body>
</html>