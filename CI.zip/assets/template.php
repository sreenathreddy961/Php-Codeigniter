<html>
<head>
<style>
	.left 
	{
  		left: 0;
  		width:10%;
  		height:1010px;
  		margin-top:7%;
  		position: absolute;
  		background-color: #123;
	}
	.left a 
	{
		color:black;
    	text-decoration:none;
	}
</style>
</head>
<body>
<div class="split left" id="left">
<pre>

  <a href="https://www.google.com/intl/en-GB/gmail/about/#" >Gmail</a>
  
  <a href="https://www.linkedin.com/login" >LinkedIn</a>
  
  <a href="https://www.w3schools.com/" >W3 Sch.</a>
</pre>
</div>
</html>