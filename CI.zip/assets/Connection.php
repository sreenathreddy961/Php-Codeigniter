<?php
	$con = mysqli_connect("localhost","root","","sreenath") or die("Server Timed Out");
?>